Royal Rags - Minecraft Java 1.21.1
Leather: Rags; Chainmail: Street Fighter; Iron: Bodyguard; Gold: Tycoon; Diamond: Prince; Netherite: King.
Install ZIP into .minecraft/resourcepacks and enable it.
This pack changes worn armor textures, not armor item icons or block textures.
