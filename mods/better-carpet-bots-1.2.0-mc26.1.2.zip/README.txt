Better Carpet Bots 1.2.0 для Minecraft Java Edition 26.1.2

Распакуйте архив и поместите JAR в папку mods, заменив старую версию.
Требуются Fabric Loader >= 0.18.4, Carpet для 26.1.2 и Java 25.

В исходном JAR исправлена строгая зависимость от Minecraft 26.1 на 26.1.2.
Проверены запуск сервера, создание бота, команды attack/stop/kill и открытие инвентаря.

Автор исходного мода: Matej Stastny. Лицензия: MIT.
Исходный проект: https://github.com/matejstastny/better-carpet-bots
